import axios from 'axios'
import React from 'react'

export const FetchAPI = async () => {
  try{
    const FetchData = await axios.get("https://dummyjson.com/products");
    return FetchData;
  }
  catch(error){
    console.error("API not Found" , error)
  }
}