import { createBrowserRouter, Outlet, RouterProvider } from "react-router-dom";
import Navbar from "./Components/NavFoot/Navbar"
import HomeLayout from "./Pages/HomeLayout"
import Footer from "./Components/NavFoot/Footer";
import Contact from "./Pages/Contact";
import AllProductShow from "./Components/Category/AllProductShow";
import ProductDetails from "./Components/Category/ProductDetails";
const App = () => {
  const AppLayOut = () => {
    return (
      <>
        <Navbar />
        <Outlet />
        <Footer/>
      </>
    );
  };
  const route = createBrowserRouter([
    {
      path: "/",
      element: <AppLayOut />,
      children: [
        {
          path: "/",
          element: <HomeLayout />,
        },
        {
          path: "/contact",
          element: <Contact/>,
        },
        {
          path: "/product/:id",
          element: <AllProductShow/>
        },
        {
          path: "/product/:id/:detailid",
          element: <ProductDetails/>
        }
      ],
    },
  ]);
  return (
    <>
        <RouterProvider router={route} />
    </>
  );
};

export default App;
