import React from 'react'
import { FiShoppingCart } from "react-icons/fi";
import { FiSearch } from "react-icons/fi";
import { useNavigation } from 'react-router-dom';
import { FaBarsStaggered } from "react-icons/fa6";

const Navbar = () => {
  const navigate = useNavigation()
  return (
    <div>
      <div className="bg-DarkColor py-2 hidden lg:block">
        <div className='container'>
          <div className='flex items-center justify-between'>
            <a href="" className=''><span className='MainFont text-white text-3xl font-extrabold'>Logo Design</span></a>
            <div className='rounded-2xl w-1/2 py-2 px-5  bg-White flex items-center justify-between'>
              <input type="text" placeholder='What are you looking for?' className='focus:outline-none bg-transparent'/>
              <span><FiSearch className='text-xl'/></span>
            </div>
            <div className='relative'>
              <FiShoppingCart className='text-3xl text-white'/>
              <span className="absolute -right-2 -top-1 w-4 h-4 bg-White rounded-full text-center leading-[16px] inline-block">0</span>
            </div>
          </div>
        </div>
      </div>
      <div className='bg-White shadow-md py-2'>
        <div className="container">
            <div className='flex items-center justify-between'>
              <a href="" className='text-DarkColor text-3xl MainFont block lg:hidden'>Logo Design</a>
              <ul className='hidden lg:flex items-center gap-x-10 '>
                <li><a onClick={()=>navigate('/')} className='text-DarkColor MainFont text-md'>Home</a></li>
                <li><a onClick={()=>navigate('/product')} className='text-DarkColor MainFont text-md'>Products</a></li>
                <li><a href="" className='text-DarkColor MainFont text-md'>Reviews</a></li>
                <li><a href="" className='text-DarkColor MainFont text-md'>Blogs</a></li>
                <li><a onClick={()=>navigate('/contact')} className='text-DarkColor MainFont text-md'>Contact</a></li>
              </ul>
              <div className='block lg:hidden text-DarkColor text-2xl'><FaBarsStaggered/></div>
            </div>
        </div>
      </div>
    </div>
  )
}

export default Navbar