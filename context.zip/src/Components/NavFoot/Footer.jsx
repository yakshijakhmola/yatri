import React from 'react'
import { FaFacebookF } from "react-icons/fa6";
import { FaInstagram } from "react-icons/fa6";
import { FaLinkedinIn } from "react-icons/fa6";
import { FaXTwitter } from "react-icons/fa6";
import { FaYoutube } from "react-icons/fa6";

const Footer = () => {
    const year = new Date().getFullYear()
  return (
    <footer className='bg-DarkColor py-5'>
        <div className="container">
            <div className="top-footer flex items-center justify-between flex-wrap">
                <a href="" className=''><span className='MainFont text-white text-3xl font-extrabold'>Logo Design</span></a>
                <div className='flex items-center gap-x-5'>
                    <a className='w-10 h-10 rounded-full border border-solid border-zinc-100 flex items-center justify-center text-White hover:bg-White hover:text-DarkColor transition-all delay-300 ease-linear'><FaFacebookF/></a>
                    <a className='w-10 h-10 rounded-full border border-solid border-zinc-100 flex items-center justify-center text-White hover:bg-White hover:text-DarkColor transition-all delay-300 ease-linear'><FaInstagram/></a>
                    <a className='w-10 h-10 rounded-full border border-solid border-zinc-100 flex items-center justify-center text-White hover:bg-White hover:text-DarkColor transition-all delay-300 ease-linear'><FaLinkedinIn/></a>
                    <a className='w-10 h-10 rounded-full border border-solid border-zinc-100 flex items-center justify-center text-White hover:bg-White hover:text-DarkColor transition-all delay-300 ease-linear'><FaXTwitter/></a>
                    <a className='w-10 h-10 rounded-full border border-solid border-zinc-100 flex items-center justify-center text-White hover:bg-White hover:text-DarkColor transition-all delay-300 ease-linear'><FaYoutube/></a>
                </div>
            </div>
            <hr className='my-5 border-1 border-solid border-[rgba(255,255,255,0.1)] py-2'/>
            <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5">
                <div>
                    <h3 className='text-White text-3xl mb-3'>About</h3>
                    <ul>
                        <li><a className='text-md text-[rgba(255,255,255,0.8)] hover:text-White' href="">Contact Us</a></li>
                        <li><a className='text-md text-[rgba(255,255,255,0.8)] hover:text-White' href="">About Us</a></li>
                        <li><a className='text-md text-[rgba(255,255,255,0.8)] hover:text-White' href="">Careers</a></li>
                        <li><a className='text-md text-[rgba(255,255,255,0.8)] hover:text-White' href="">Press</a></li>
                        <li><a className='text-md text-[rgba(255,255,255,0.8)] hover:text-White' href="">Flipkart Stories</a></li>
                    </ul>
                </div>
                <div>
                    <h3 className='text-White text-3xl mb-3'>Group Companies</h3>
                    <ul>
                        <li><a className='text-md text-[rgba(255,255,255,0.8)] hover:text-White' href="">Shopify</a></li>
                        <li><a className='text-md text-[rgba(255,255,255,0.8)] hover:text-White' href="">Myntra</a></li>
                        <li><a className='text-md text-[rgba(255,255,255,0.8)] hover:text-White' href="">Cleartrip</a></li>
                    </ul>
                </div>
                <div>
                    <h3 className='text-White text-3xl mb-3'>Consumer Policy</h3>
                    <ul>
                        <li><a className='text-md text-[rgba(255,255,255,0.8)] hover:text-White' href="">Cancellations & Returns</a></li>
                        <li><a className='text-md text-[rgba(255,255,255,0.8)] hover:text-White' href="">Terms of use</a></li>
                        <li><a className='text-md text-[rgba(255,255,255,0.8)] hover:text-White' href="">Security</a></li>
                        <li><a className='text-md text-[rgba(255,255,255,0.8)] hover:text-White' href="">Privacy</a></li>
                        <li><a className='text-md text-[rgba(255,255,255,0.8)] hover:text-White' href="">Sitemap</a></li>
                    </ul>
                </div>
                <div>
                    <h3 className='text-White text-3xl mb-3'>About</h3>
                    <ul>
                        <li><a className='text-md text-[rgba(255,255,255,0.8)] hover:text-White' href="">Contact Us</a></li>
                        <li><a className='text-md text-[rgba(255,255,255,0.8)] hover:text-White' href="">About Us</a></li>
                        <li><a className='text-md text-[rgba(255,255,255,0.8)] hover:text-White' href="">Careers</a></li>
                        <li><a className='text-md text-[rgba(255,255,255,0.8)] hover:text-White' href="">Press</a></li>
                        <li><a className='text-md text-[rgba(255,255,255,0.8)] hover:text-White' href="">Flipkart Stories</a></li>
                    </ul>
                </div>
                <div>
                    <h3 className='text-White text-3xl mb-3'>About</h3>
                    <ul>
                        <li><a className='text-md text-[rgba(255,255,255,0.8)] hover:text-White' href="">Contact Us</a></li>
                        <li><a className='text-md text-[rgba(255,255,255,0.8)] hover:text-White' href="">About Us</a></li>
                        <li><a className='text-md text-[rgba(255,255,255,0.8)] hover:text-White' href="">Careers</a></li>
                        <li><a className='text-md text-[rgba(255,255,255,0.8)] hover:text-White' href="">Press</a></li>
                        <li><a className='text-md text-[rgba(255,255,255,0.8)] hover:text-White' href="">Flipkart Stories</a></li>
                    </ul>
                </div>
            </div>
            <hr className='my-5 border-1 border-solid border-[rgba(255,255,255,0.1)]'/>
            <div className="bottom-footer">
                <p className='text-md text-White'>© Copyright & all reserved by LogoDesign.com {year}</p>
            </div>
        </div>
    </footer>
  )
}

export default Footer