import axios from 'axios';
import React, { useEffect, useState } from 'react';
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Slider from "react-slick";
import { FetchAPI } from '../../Constant/Service';
import { useNavigate } from 'react-router-dom';
import Cookies from 'js-cookie';

const CategorySingleCard = () => {
    const navigate = useNavigate();
    const [catcard, setCatCard] = useState([]);
    const handleNavigate = (id) =>{
        Cookies.set('category', id)
        navigate(`/product/${id}`)
    }
    const CateSlider = {
        dots: false,
        infinite: true,
        speed: 300,
        slidesToShow: 7,
        slidesToScroll: 1,
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 1,
                    infinite: true,
                    dots: false
                }
            },
            {
                breakpoint: 600,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]
    };

    const CatFetchAPI = async () => {
        try {
            const CatFetchData = await FetchAPI();
            setCatCard(CatFetchData.data.products);

            console.log("Fetched Products:", CatFetchData.data);
        } 
        catch (error) {
            console.error("Category Not Found", error);
        }
    };

    useEffect(() => {
        CatFetchAPI();
    }, []);

    return (
        <div className='ptb'>
            <div className="container">
                <Slider {...CateSlider}>
                    {catcard.map((catval) => (
                        <div key={catval.id} onClick={()=>handleNavigate(catval.category)}>
                            <div  className='m-2 flex items-center justify-center flex-col'>
                                <img 
                                    className='w-40 h-40 rounded-full object-cover border-2 border-solid border-zinc-100 p-1 hover:border-DarkColor' 
                                    src={catval.thumbnail} 
                                    alt={catval.title || "Category Image"} 
                                />
                                <h5 className='text-center capitalize text-xl text-DarkColor mt-4 line-clamp-1'>
                                    {catval.title || "Unknown Category"}
                                </h5>
                            </div>
                        </div>
                    ))}
                </Slider>
            </div>
        </div>
    );
};

export default CategorySingleCard;
