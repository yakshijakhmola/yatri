import React, { useState, useEffect } from 'react'
import { useParams } from 'react-router-dom';
import { FetchAPI } from '../../Constant/Service';
import Cookies from 'js-cookie';

const ProductDetails = () => {
    const [detailcard, setDetailCard] = useState([]);
    const [detailfetch, setDetailfetch] = useState([])
    const  {category} = useParams();
    const getproductId = Cookies.get('productId')

    const CatFetchAPI = async () => {
        try {
          const CatFetchData = await FetchAPI();
          const products = CatFetchData.data.products || [];
          setDetailCard(products)
          const filtered = products.filter((val) =>{
            return val.id == getproductId
          });
          setDetailfetch(filtered);
        } catch (error) {
          console.error('Category Not Found', error);
        }
      };
    
      useEffect(() => {
        CatFetchAPI();
      }, []);
  return (
    <div className='py-10'>
        <div className="container">
            {detailfetch.map((val)=>(
                <div className="grid grid-cols-12 gap-x-5">
                    <div className="col-span-6">
                        <img className='shadow-md' src={val.images} alt="" />
                    </div>
                    <div className="col-span-6">
                        <span className='text-DarkColor mb-3'>{val.category}</span>
                        <h2 className='font-bold text-4xl mb-3'>{val.title}</h2>
                        <h4>₹{val.price}/-</h4>
                        <ul>
                            <h5>Colour: </h5>
                            <li><p>Pink</p></li>
                            <li><p>Black</p></li>
                            <li><p>Green</p></li>
                        </ul>
                    </div>
                </div>
            ))}
        </div>
    </div>
  )
}

export default ProductDetails