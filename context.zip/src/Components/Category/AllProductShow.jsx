import React, { useState, useEffect } from 'react';
import Cookies from 'js-cookie'; // Ensure the library is installed
import { FetchAPI } from '../../Constant/Service';
import { useNavigate } from 'react-router-dom';
import { useParams } from 'react-router-dom';

const AllProductShow = () => {
  const navigate = useNavigate()
  const [catcard, setCatCard] = useState([]);
  const [filtercat, setFilterCat] = useState([]);
  const getcategory = Cookies.get('category');
  const {detailid} = useParams()
  const HandleNav = (detailid)=>{
    Cookies.set('productId',detailid)
    navigate(`/${detailid}`)
  }

  const CatFetchAPI = async () => {
    try {
      const CatFetchData = await FetchAPI();
      const products = CatFetchData.data.products || [];
      setCatCard(products);

      console.log('Fetched Products:', products);

      // Filter products by category after fetching
      const filtered = products.filter((val) => val.category === getcategory);
      setFilterCat(filtered);
    } catch (error) {
      console.error('Category Not Found', error);
    }
  };

  useEffect(() => {
    CatFetchAPI();
  }, []); // Only run once on component mount

  return (
    <div className='py-10'>
      <div className="container">
        <div className="grid grid-cols-12">
          {filtercat.length > 0 ? (
            filtercat.map((val, id) => (
              <div className="col-span-12 lg:col-span-3 m-2" key={id}>
                <div className='bg-white shadow-md p-5'>
                  <h3 className='text-xl'>{val.title}</h3>
                  <img className='mx-auto w-40 my-3' src={val.images} alt="" />
                  <p className='mb-3'>{val.description}</p>
                  <h5 className='text-3xl font-bold'>₹{val.price}/-</h5>
                  <a onClick={()=>HandleNav(val.title)} className='text-DarkColor font-bold'>View More</a>
                </div>
              </div>
            ))
          ) : (
            <p>No products found for this category.</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default AllProductShow;
