import React from 'react'
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Slider from "react-slick";
import { assets } from '../assets/assets';

const HeroSlider = () => {
    const HeroSliderImg = [
        {
            id: 1,
            Banner_img: assets.Banner1,
        },
        {
            id: 2,
            Banner_img: assets.Banner2,
        },
        {
            id: 3,
            Banner_img: assets.Banner3,
        }
    ]
    var settings = {
        dots: false,
        infinite: true,
        speed: 500,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 1000,
    };
  return (
    <Slider {...settings}>
        {HeroSliderImg.map((heroval)=>(
            <div key={heroval.id}>
                <img src={heroval.Banner_img} alt="" />
            </div>
        ))}
    </Slider>
  )
}

export default HeroSlider