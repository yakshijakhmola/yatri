import React from 'react'

const Contact = () => {
  return (
    <div className='py-10'>
        <div className="container">
            <div className='flex items-center justify-center'>
                <div className='grid grid-cols-1'>
                    <div className='bg-White shadow-md px-4 py-8'>
                        <h2 className='text-DarkColor text-4xl mb-3'>Tell Us Your Query</h2>
                        <form action="">
                            <div className='mb-3'>
                                <label className='text-xl mb-2 inline-block'>Name</label>
                                <input type="text" placeholder='Name*' className='w-full focus:outline-none border border-solid border-DarkColor rounded-sm py-2 px-3' required/>
                            </div>
                            <div className='mb-3'>
                                <label className='text-xl mb-2 inline-block'>Email</label>
                                <input type="email" placeholder='Email*' className='w-full focus:outline-none border border-solid border-DarkColor rounded-sm py-2 px-3' required/>
                            </div>
                            <div className='mb-3'>
                                <label className='text-xl mb-2 inline-block'>Phone Number</label>
                                <input type="text" placeholder='Phone Number*' className='w-full focus:outline-none border border-solid border-DarkColor rounded-sm py-2 px-3' required/>
                            </div>
                            <div className='mb-3'>
                                <label className='text-xl mb-2 inline-block'>Select Your Category</label>
                                <select name="" id="" className='w-full focus:outline-none border border-solid border-DarkColor rounded-sm py-2 px-3'>
                                    <option value="Mobile">Mobile</option>
                                    <option value="Clothes">Clothes</option>
                                    <option value="Accessories">Accessories</option>
                                    <option value="Watch">Watch</option>
                                    <option value="Laptop">Laptop</option>
                                    <option value="Kitchen Appliances">Kitchen Appliances</option>
                                </select>
                            </div>
                            <div className='mb-3'>
                                <label className='text-xl mb-2 inline-block'>Write Your Query</label>
                                <textarea type="text" placeholder='Write Your Query*' className='w-full focus:outline-none border border-solid border-DarkColor rounded-sm py-2 px-3 h-20'></textarea>
                            </div>
                            <button className='text-DarkColor text-center py-2 px-4 border border-solid border-DarkColor transition-all delay-100 ease-linear hover:bg-DarkColor hover:text-White'>Submit Enquiry</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
  )
}

export default Contact