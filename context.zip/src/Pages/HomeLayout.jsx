import React from 'react'
import HeroSlider from './HeroSlider'
import CategorySingleCard from '../Components/Category/CategorySingleCard'
import ProductDetails from "../Components/Category/ProductDetails"

const HomeLayout = () => {
  return (
    <>
      <HeroSlider/>
      <CategorySingleCard/>
      <ProductDetails/>
    </>
  )
}

export default HomeLayout