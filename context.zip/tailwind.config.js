/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors:{
        'White': '#ffffff',
        'Black': '#010606',
        'DarkColor': '#5e0d8b',
        'Lightcolor': '#f6e6ff',
        'MiddleColor': '',
        'MainHeadColor': '#010606',
        'ParaColor': '#757575',
      },
      FontFamily:{
        'MainFont': '"Itim", cursive;',
        'ParaFont': 'Raleway',
      },
      container: {
        center: true,
        padding: {
          DEFAULT: '1rem',
          sm: '2rem',
          lg: '4rem',
          xl: '5rem',
          '2xl': '6rem',
        },
      },
    },
  },
  plugins: [],
}